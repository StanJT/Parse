$scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
Join-Path $scriptDir "BadParse.ps1"
clear-host

$Copy = Read-Host "Copy Control file to local directory for test? [Y] / [N]"

Write-Host $Copy

if ($Copy -eq "y") {

      new-item -path "C:\users\$([Environment]::UserName)\Documents" -name "Parse" -ItemType "directory"
      copy-item $scriptDir\Control.ps1 -destination "C:\users\$([Environment]::UserName)\Documents\Parse"
} elseif ($Copy -eq "n") {
 {throw}
} else {
exit
}


Clear-Host
{catch}

$File = "https://raw.githubusercontent.com/StanJT/Parse/main/BadFile.ps1"

if ($File.contains(".docx") -or $File.contains(".doc") -or $File.contains(".txt") -or $File.contains(".ps1"))
{
Clear-Host

new-item -path "c:\users\Public" -name "Tmp" -ItemType "directory"
Invoke-WebRequest "https://raw.githubusercontent.com/StanJT/Parse/main/BadFile.ps1" -OutFile "C:\users\$([Environment]::UserName)\Documents\Parse\BadFile.ps1"
}



$Parse = Compare-Object -IncludeEqual (Get-Content -Path "C:\users\$([Environment]::UserName)\Documents\Parse\Control.ps1") (Get-Content -Path "C:\users\$([Environment]::UserName)\Documents\Parse\BadFile.ps1")


if ($Parse.SideIndicator -eq "<=" -or $Parse.SideIndicator -eq "=>") {
      Write-Host "Error Detected"
      Write-Host ""
      Write-Host "Test Complete"
      Write-Host ""
      Write-Host "Thank you for checking out this script. I hope you may find use for it!"
      Write-Host "Please press any key to continue!"
      [void] (Read-Host"")
      clear-host

      $Clear = Read-host "Clear Test files? [Y] / [N]"
      write-host $Clear

            if ($Clear = "Y") {
                  Remove-item -LiteralPath "C:\users\$([Environment]::UserName)\Documents\Parse"  -force -recurse
                  exit
            } else {

            exit
            } 
      } Elseif ($Parse.SideIndicator -eq "==") {
            Clear-Host 
            $Yay = "Everything Checks Out!"
            Remove-item -LiteralPath 'C:\Users\Public\Tmp' -force -recurse
            {throw}
            } else {
            Write-Host "Control FIle Missing"
            Write-Host ""
            Write-Host "Please fix error and try running again"
            Read-Host "Press any key to exit"
            exit
      }
{catch}
clear-host
Write-Host $Yay
Write-Host ""
Write-Host "Test Complete"
Write-Host ""
Write-Host "Thank you for checking out this script. I hope you may find use for it!"
Write-Host "Please press any key to continue!"
[void] (Read-Host"")
clear-host

$Clear = Read-host "Clear Test files? [Y] / [N]"
write-host $Clear

if ($Clear = "Y") {
      Remove-item -LiteralPath "C:\users\$([Environment]::UserName)\Documents\Parse"  -force -recurse
} else {

exit
}