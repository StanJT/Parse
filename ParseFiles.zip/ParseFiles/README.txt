This file is used for test purposes only. Its scope is to give a generalized idea of the process that would be performed.

This is an open source project and as such the original PS1 files have not been obfuscated or compiled.
To view the files change the folder permissions for the ParseFiles folder to show hidden items.

Common Errors:

Script Auto-Terminating

Check to see if powershell is set as the default program for .PS1 files.

Check to see if your machine prevents the execution of scripts.


Control File Missing

If an error is occuring where the control file cannot be found: make sure you have chosen to copy the control file by selecting [y] at the beginning of the script.

This portion emulates an organization having manually placed the control script on their segregated server for their validation and parsing purposes.


Control File Not Copying

This is most like a permissions issue.
To resolve this either change file permissions on the folder path or open the script and redirect it towards anoth folder
**NOTE, this will change will need to be made for each instance of the path in both the GoodParse.PS1 and BadParse.PS1 files.




Disclaimer
All items and information contained within the project are the intellectual properties of Jacob Stanford.